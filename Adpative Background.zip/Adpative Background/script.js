 // Search in your bundle and replace this part
 
 p.forEach(function(n){var i=t+"-"+n+" {"+n+":"+e+"!important;}\n";y.insertRule(i,0)})}
 
 // with this part
 
 p.forEach(function(n){var i=t+"-"+n+" {"+n+":"+e+"!important;}\n";if(n==="background-color"){if(e!=undefined && e!=""){var rgb = e.match(/\d+/g);var r=parseInt(rgb[0])/255;var g=parseInt(rgb[1])/255;var b=parseInt(rgb[2])/255;var min = Math.min(r,g,b);var max = Math.max(r,g,b);if (min==max)y.insertRule("#header::after{-webkit-filter: hue-rotate(0deg) !important;}",0);var d = (r==min) ? g-b : ((b==min) ? r-g : b-r);var h = (r==min) ? 3 : ((b==min) ? 1 : 5);y.insertRule("#header::after{-webkit-filter: hue-rotate(" + (60*(h - d/(max - min))) + "deg) !important;}",0);}}y.insertRule(i,0)})}
 
 
 // Here is the script more clean
 
 if(e!=undefined&&e!=""){ //If the color exists
 	var rgb = e.match(/\d+/g); //Extract the colors
 	
 	var r=parseInt(rgb[0])/255; //Calculate the hue
 	var g=parseInt(rgb[1])/255;
 	var b=parseInt(rgb[2])/255;
 	
 	var min = Math.min(r,g,b);
 	var max = Math.max(r,g,b);
 	
 	//If the image don't have color (black and white) then make the image red
 	if (min==max)  y.insertRule("#header::after{-webkit-filter: hue-rotate(0deg) !important;}",0);
 	
 	var d = (r==min) ? g-b : ((b==min) ? r-g : b-r);
 	var h = (r==min) ? 3 : ((b==min) ? 1 : 5);
 	
 	//Change the color of the image
 	y.insertRule("#header::after{-webkit-filter: hue-rotate(" + (60*(h - d/(max - min))) + "deg) !important;}",0);
 }
 
 //If you have Custom Selection Colour in of An_dz change the first code with
  p.forEach(function(n){var i=t+"-"+n+" {"+n+":"+e+"!important;}\n";if(n==="background-color"){y.insertRule("::selection{"+n+":"+e+"}", 0);if(e!=undefined && e!=""){var rgb = e.match(/\d+/g);var r=parseInt(rgb[0])/255;var g=parseInt(rgb[1])/255;var b=parseInt(rgb[2])/255;var min = Math.min(r,g,b);var max = Math.max(r,g,b);if (min==max)y.insertRule("#header::after{-webkit-filter: hue-rotate(0deg) !important;}",0);var d = (r==min) ? g-b : ((b==min) ? r-g : b-r);var h = (r==min) ? 3 : ((b==min) ? 1 : 5);y.insertRule("#header::after{-webkit-filter: hue-rotate(" + (60*(h - d/(max - min))) + "deg) !important;}",0);}}y.insertRule(i,0)})}
 
